package com.example.hesabyar

import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
